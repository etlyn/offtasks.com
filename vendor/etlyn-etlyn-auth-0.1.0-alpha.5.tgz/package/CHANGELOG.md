# 0.1.0-alpha.5 — 2026-10-28

Correct the tab-local return-path example to configure the Google helper. Runtime behavior is unchanged from alpha.4.

# 0.1.0-alpha.4 — 2026-10-28

Use an exact query-free Google callback so Supabase does not silently redirect to a different product's Site URL. Hosts can retain validated navigation in tab-local storage and a last-used sign-in hint in device-local storage; neither stores credentials or grants access. Storage denial keeps authentication available.

# 0.1.0-alpha.3 — 2026-10-28

Add a shared Google sign-in/PKCE callback helper with same-origin return paths, sanitized cancellation/errors and host-owned URL cleanup. Supabase remains the only session owner; this does not grant Etlyn access or enable any provider.

# 0.1.0-alpha.2

First registry rollout. Refresh requests call the provider refresh API. Native secure storage uses full-value Keychain persistence; legacy sessions move only after a successful secure write.

# Changelog

## 0.1.0-alpha.1 - 2026-10-04

- added `typesVersions` so TypeScript projects using `moduleResolution: node` resolve the `/react`, `/cookie`, `/supabase` and `/react-native` subpaths

## 0.1.0-alpha.0 - 2026-10-03

- extracted the provider-neutral auth session state machine from the CMS boundary into a standalone package
- added typed identity and authenticated-fetch helpers for the Etlyn `/identity/me` contract
- added React, cookie-session, Supabase, and React Native entry points without UI or routing concerns
- added deterministic unit coverage for stale requests, duplicate mutations, identity error mapping, refresh-once fetch, secure-storage chunking, and deep-link PKCE handling
