/** Optional host-supplied web storage for navigation and a local UI hint only. */
export interface SignInStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export type SignInHint = {
    method: 'google' | 'password';
    email: string;
};
/** Storage denial/private mode must never prevent authentication. */
export declare function createReturnPathStore(storage: () => SignInStorage, key: string): {
    read(): string | null;
    write(path: string): void;
    clear(): void;
};
/** Device-local last-used hint; never an account/provider lookup or access grant. */
export declare function createSignInHintStore(storage: () => SignInStorage, key: string): {
    read(): SignInHint | null;
    remember(method: SignInHint["method"], email: string): void;
};
//# sourceMappingURL=browser-sign-in.d.ts.map