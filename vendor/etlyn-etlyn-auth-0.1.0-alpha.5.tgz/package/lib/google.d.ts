export interface GoogleAuthClient {
    auth: {
        signInWithOAuth?: (options: {
            provider: 'google';
            options: {
                redirectTo: string;
            };
        }) => Promise<{
            error?: {
                message?: string;
            } | null;
        }>;
        exchangeCodeForSession?: (code: string) => Promise<{
            error?: {
                message?: string;
            } | null;
        }>;
    };
}
export interface GoogleAuthOptions {
    client: GoogleAuthClient;
    origin: string;
    callbackPath?: string;
    returnPathParameter?: string;
    fallback?: string;
    /** Host-owned, tab-local navigation state. Never store OAuth codes or tokens. */
    returnPathStore?: {
        read(): string | null;
        write(path: string): void;
        clear(): void;
    };
    /** Host removes transient callback parameters before any asynchronous work. */
    scrubCallbackUrl?: (relativeUrl: string) => void;
}
/** Supabase owns OAuth state, PKCE, identities and sessions; this helper owns no storage. */
export declare function createSupabaseGoogleAuth(options: GoogleAuthOptions): {
    start(returnPath?: string | null): Promise<void>;
    complete(urlValue: string): Promise<{
        returnPath: string;
    }>;
};
//# sourceMappingURL=google.d.ts.map